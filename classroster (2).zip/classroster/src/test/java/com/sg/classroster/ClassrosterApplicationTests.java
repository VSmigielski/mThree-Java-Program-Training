package com.sg.classroster;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Configuration;

@Configuration
@SpringBootTest
class ClassrosterApplicationTests {

	@Test
	void contextLoads() {
	}

}
