var addedMoney = 0;

$(document).ready(function () {
    loadItems();
    updateMoney(addedMoney);

    $('#addDollarButton').on('click', function () {
        addedMoney += 1;
        messageBox("You added $1.00");
        updateMoney(addedMoney);
    });

    $('#addQuarterButton').on('click', function () {
        addedMoney += .25;
        messageBox("You added $0.25")
        updateMoney(addedMoney);
    });

    $('#addDimeButton').on('click', function () {
        addedMoney += .10;
        messageBox("You added $0.10");
        updateMoney(addedMoney);
    });

    $('#addNickelButton').on('click', function () {
        addedMoney += .05;
        messageBox("You added $0.05")
        updateMoney(addedMoney);
    });

    $('#purchaseButton').click(function () {
        makePurchase();
    });

    $('#returnChange').on('click', function () {
        returnChange();
    });

});

function loadItems() {
    //clearItemsTable();
    var grid1 = $('#gridContentCol1');
    var grid2 = $('#gridContentCol2');
    var grid3 = $('#gridContentCol3');

    const formatToCurrency = amount => {
        return amount.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, "$&,");
      };

    $.ajax({
        type: 'GET',
        url: 'http://tsg-vending.herokuapp.com/items',
        success: function(itemArray) {
            $.each(itemArray, function(index, item){
                var id = item.id;
                var name = item.name;
                var price = item.price;
                var quantity = item.quantity;
                var card = '<div class="card" onclick="selectedItem(' + id + ')" style="height:225px; text-align:center; font-weight:700">';
                    card += '<div class="card-body">';
                    card += '<div style="text-align:left">' + id + '</div>';
                    card += '<br />' + name + '<br /><br />';
                    card += '$'+ formatToCurrency(price) + '<br /><br />';
                    card += 'Quantity Left: ' + quantity + '</div></div><br />';
                
                    if(index % 3 == 0){
                    grid1.append(card);
                }
                else if(index % 3 == 1){
                    grid2.append(card);
                }
                else if(index % 3 == 2){
                    grid3.append(card);
                }

            })
        },
        error: function() {
            $('#errorMessages')
                .append($('<li>')
                .attr({class: 'list-group-item list-group-item-danger'})
                .text('Error calling web service. Please try again later.'));
        }
    });
}

function messageBox(message) {
    $('#vendingMessage').val(message);
}

function updateMoney(money) {
    $('#moneyInput').empty();
    $('#moneyInput').val(money.toFixed(2));
}

function selectedItem(id) {
    $('#itemToVend').val(id);
}
 
function makePurchase() {
    var money = $('#moneyInput').val();
    var item = $('#itemToVend').val();

    $.ajax({
        type: 'POST',
        url: 'http://tsg-vending.herokuapp.com/money/' + money + '/item/' + item,
        success: function (change) {
            var change = $('#changeInputBox');
            $('#vendingMessage').val("Item vended.");
            var pennies = change.pennies;
            var nickels = change.nickels;
            var quarters = change.quarters;
            var dimes = change.dimes;
            var returnMessage = change.message;
            if (quarters != 0) {
                returnMessage += quarters + ' Quarter/s ';              
            }
            if (dimes != 0) {
                returnMessage += dimes + ' Dime/s ';                     
            }
            if (nickels != 0) {
                returnMessage += nickels + ' Nickel/s ';                 
            }
            if (pennies != 0) {
                returnMessage += pennies + ' Penny/ies ';              
            }
            if (quarters == 0 && dimes == 0 && nickels == 0 && pennies == 0) {
                returnMessage += "There is no change";                  
            }
            change.val(returnMessage);                                 
            $('#moneyInput').val('');
            loadItems();
            addedMoney = 0;
        },
        error: function (jqXHR, textStatus, errorThrown) {
            alert("Error:" + jQuery.parseJSON(jqXHR.responseText).Info); //Error
 
        }
    
  });
}

function returnChange() {
    var addedMoney = $('#moneyInput').val();
    var money = $('#moneyInput').val();

    var quarter = Math.floor(money / 0.25);
    money = (money - quarter * 0.25).toFixed(2);
    var dime = Math.floor(money / 0.10);
    money = (money - dime * 0.10).toFixed(2);
    var nickel = Math.floor(money / 0.05);
    money = (money - nickel * 0.05).toFixed(2);
    var penny = Math.floor(money / 0.01);
    money = (money - penny * 0.01).toFixed(2);

    var returnMessage = "";
    var vendingMessage = "";

    if (quarter != 0) {
        returnMessage += quarter + ' Quarter/s ';    
    }   
    if (dime != 0) {
        returnMessage += dime + ' Dime/s ';      
    }
    if (nickel != 0) {
        returnMessage += nickel + ' Nickel/s ';      
    }
    if (penny != 0) {
        returnMessage += penny + ' Penny/ies ';                   
    }
    if (quarter == 0 && dime == 0 && nickel == 0 && penny == 0) {
        returnMessage += "There is no change.";   
        vendingMessage = "No money was inputted.";             
    } else {
        vendingMessage = "Transaction cancelled. Money inputted ($" + addedMoney + ") is returned through change.";
    }

    addedMoney = 0;
    messageBox("");
    $('#vendingMessage').val(vendingMessage);
    $('#changeInputBox').val(returnMessage);
    $('#itemToVend').val('');
    $('#moneyInput').val('');   
}

