package com.sg.superheroessightings;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SuperheroessightingsApplicationTests {

	@Test
	void contextLoads() {
	}

}
